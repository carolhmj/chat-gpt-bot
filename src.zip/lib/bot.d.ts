import { ActivityHandler } from "botbuilder";
export declare class EchoBot extends ActivityHandler {
    constructor();
}
