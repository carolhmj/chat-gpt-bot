export declare const discourseApiKey: string;
export declare const discourseApiUser: string;
export declare const openApiKey: string;
export declare const openApiEndpoint: string;
