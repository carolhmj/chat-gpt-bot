export declare class OpenApi {
    private _apiKey;
    private _apiEndpoint;
    constructor(apiKey: string, apiEndpoint: string);
    getResponse(text: string): Promise<any>;
}
