/**
 * This class is responsible for communicating with the Discourse API.
 */
export declare class DiscourseApi {
    private _apiKey;
    private _apiUsername;
    private _modIds;
    constructor(apiKey: string, apiUsername: string);
    buildModsList(): Promise<void>;
    getTopicId(topicUrl: string): Promise<any>;
    private _topicHasModAttention;
    /**
     * List latest question topics
     */
    listLatestQuestions(): Promise<any>;
    getFirstPostText(topicUrl: string): Promise<any>;
    post(topicId: string, text: string): Promise<string>;
    filterForUnmodedTopics(topics: any[]): any[];
}
