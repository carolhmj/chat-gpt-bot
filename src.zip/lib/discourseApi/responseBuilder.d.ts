/**
 * This class builds formatted text responses
 */
export declare class ResponseBuilder {
    static buildTopicListResponse(topics: any[]): string;
}
