const axios = require("axios").default;

export class OpenApi {
    private _apiKey: string;
    private _apiEndpoint: string;

    constructor(apiKey: string, apiEndpoint: string) {
        this._apiKey = apiKey;
        this._apiEndpoint = apiEndpoint;
    }

    public async getResponse(text: string) {
        const options = {
            method: "GET",
            url: this._apiEndpoint,
            headers: {
                "Authorzation": "Bearer " + this._apiKey,
            },
        };

        const result = await axios(options);
        return result.data;
    }
}