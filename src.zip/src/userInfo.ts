export const discourseApiKey = process.env.DiscourseApiKey;
export const discourseApiUser = process.env.DiscourseApiUser;
export const openApiKey = process.env.OpenApiKey;
export const openApiEndpoint = process.env.OpenApiEndpoint;